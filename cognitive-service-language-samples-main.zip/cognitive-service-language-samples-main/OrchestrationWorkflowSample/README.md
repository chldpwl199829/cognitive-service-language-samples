# Orchestration Workflow Sample

A sample .NET solution that calls the [Orchestration workflow](https://docs.microsoft.com/en-us/azure/cognitive-services/language-service/orchestration-workflow/overview) service using the Conversations SDK. 

## Getting Started

Follow the [tutorial](https://docs.microsoft.com/en-us/azure/cognitive-services/language-service/orchestration-workflow/tutorials/connect-services) in the Orchestration workflow documentation.
